package com.ermanyalcin.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class StudentList : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_list)
    }
}